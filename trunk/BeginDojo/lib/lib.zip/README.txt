dojo库文件太多, 上传Google Code SVN很慢, 打成压缩包了
使用前先解压缩到当前目录
